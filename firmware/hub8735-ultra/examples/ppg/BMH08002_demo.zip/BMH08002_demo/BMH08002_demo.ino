/************************************************************
* Oximeter Module BMH08002 example code
* Arduino IDE version: 1.8.13
* Arduino Board: UNO R3
* Wire Connection:
*   module pin 1 (VIN) connects to UNO pin 3.3V
*   module pin 2 (TX)  connects to UNO pin 2
*   module pin 3 (RX)  connects to UNO pin 3
*   module pin 4 (GND) connects to UNO pin GND
*   module pin 5 (EN)  NC
* Created on 2022/05/04 by Best Modules Corp.
*************************************************************/

// Important: 
// This example executes query response mode. Before starting the example,
// please execute the 27&28 line comment program once
#include <Wire.h> 
#include <LiquidCrystal_I2C.h>
#include "BMH08002.h"

BMH08002 bmh08002(2,3);
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() 
{
  Serial.begin(9600); 
  delay(100);
  lcd.begin();
  lcd.backlight();
  if (bmh08002.StartMeasurement() == 1) lcd.print("Start");
  else lcd.print("Fail");
  delay(1000);
  lcd.clear(); 
  
}

void loop() 
{ 
  while(bmh08002.ReadMeasureValue(0x02) != 0x02)
  {
    lcd.print("Wait");
    delay(2000);
    lcd.clear(); 
    
  }
  lcd.setCursor(0,0);
  lcd.print("Blood = ");
  lcd.print(bmh08002.ReadMeasureValue(0x03));
  lcd.print("%");
  delay(1000);
  
  lcd.setCursor(0,1);
  lcd.print("Heart = ");
  lcd.print(bmh08002.ReadMeasureValue(0x04));
  lcd.print(" BPM");
  delay(1000);
}  
